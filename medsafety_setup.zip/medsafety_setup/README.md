# MedSafety database setup (INF2003 G61)

One script builds our whole database, all **15 tables from the ER diagram with data**, in **MySQL** or **PostgreSQL**. All the data is inside the script, so **you don't need CSV files or an Uploads folder**.

```
mysql/        medsafety_setup_mysql.sql      check_setup_mysql.sql
postgresql/   medsafety_setup_postgres.sql   check_setup_postgres.sql
README.md     this file
```

Both versions contain exactly the same data. I checked every row of all 15 tables against each other.

> ⚠️ The script **deletes and rebuilds** these tables, including the older tables from earlier versions of our scripts. Anything you added by hand will be lost.

---

## MySQL (Workbench)

**You need** MySQL Server 8.0 or newer, plus MySQL Workbench.

1. Connect to your local server in Workbench.
2. **File → Run SQL Script…**, choose `mysql/medsafety_setup_mysql.sql` and click **Run**. The script is about 2.7 MB, so use Run SQL Script rather than opening it in the editor. It creates the `medsafety` database itself and takes under a minute.
3. Open `mysql/check_setup_mysql.sql` (*File → Open SQL Script*) and run it with the **first lightning-bolt button**.
4. Every row of the result should say **PASS**.
5. To see the tables, click the refresh icon next to **SCHEMAS** in the Navigator.

## PostgreSQL (pgAdmin, DBeaver, psql, …)

**You need** PostgreSQL 12 or newer, plus any SQL tool.

1. **Create an empty database** called `medsafety`:
   - **pgAdmin:** right-click *Databases* → *Create → Database*.
   - **DBeaver:** right-click your connection → *Create → New Database*.
   - **psql:** `createdb -U postgres medsafety`
2. **Connect to that database** and run `postgresql/medsafety_setup_postgres.sql`:
   - **pgAdmin:** select `medsafety` → *Tools → Query Tool* → 📂 Open File → **F5**.
   - **DBeaver:** open the file with `medsafety` as the active database, then press **Alt+X** (*Execute SQL Script*). **Not Ctrl+Enter**, which runs only one statement.
   - **psql:** `psql -U postgres -d medsafety -f medsafety_setup_postgres.sql`
3. The last result is the CHECK table, and every row should say **PASS**. You can re-run the check any time with `check_setup_postgres.sql`.

PostgreSQL stores unquoted names in lowercase (`Patient` becomes `patient`). Write your queries **without double quotes** and they work as written, e.g. `SELECT NRIC, Name FROM Patient`.

---

## What the check shows (27 rows)

**15 `counts` rows**, one per table:

| Drug | ActiveIngredients | Contains | SideEffects | HasSideEffects | DrugtoDrugInteraction |
|---|---|---|---|---|---|
| 2202 | 2008 | 2697 | 202 | 941 | 6684 |

| Patient | Doctor | Pharmacist | Disease | Diagnosis | PrescriptionTemplate | Prescription | IsAllergicTo | ToAddress |
|---|---|---|---|---|---|---|---|---|
| 50 | 8 | 5 | 73 | 120 | 38 | 182 | 8 | 481 |

**12 `scenario` rows**, one per demo prescription waiting for a pharmacist. Each checks that the prescription raises the expected alerts against the patient's **active** medications and allergies:

| | Scenario | Expected alert |
|---|---|---|
| D1 | On metformin, new amlodipine | none |
| D2 | Amoxicillin allergy, new amoxicillin | allergy |
| D3 | On warfarin, new ibuprofen | interaction |
| D4 | On warfarin + simvastatin, new clarithromycin | multiple interactions |
| D5 | Ibuprofen allergy, on aspirin + digoxin, new ibuprofen | allergy + interactions |
| D6 | On clopidogrel, new omeprazole | interaction |
| D7 | On nitroglycerin, new sildenafil | interaction |
| D8 | On spironolactone, new lisinopril | interaction |
| D9 | On sertraline, new tramadol | interaction |
| D10 | Clarithromycin course ended months ago, new simvastatin | none (old meds don't count) |
| D11 | No medications or allergies, new cetirizine | none |
| D12 | Carbamazepine Stevens-Johnson syndrome on record, new carbamazepine | allergy |

---

## How the tables differ from the ER diagram

These are agreed design changes. **Please update the diagram to match.**

| Table | Change | Why |
|---|---|---|
| **Drug** | One row per **generic** drug (e.g. `METFORMIN HYDROCHLORIDE`, `AMOXICILLIN; CLAVULANATE POTASSIUM`). No brand names. | Strength, route and form vary per product, so they belong in the template |
| **PrescriptionTemplate** | Extra **`dosage_form`** column (TABLET, CAPSULE, AEROSOL, METERED, …) | Tells "500 mg tablet" apart from "500 mg extended-release" |
| **HasSideEffects** | `(IngredientID, EffectID)` instead of DrugID | Side effects are known per ingredient, and combination drugs inherit them. Look them up through `Contains` |
| **DrugtoDrugInteraction** | `IngredientID_A`, `IngredientID_B` instead of DrugIDs. Key is `(A, B, Symptom)`. Extra columns `Direction`, `LabelSaysAvoid`, `ExampleSentence` | One row covers every drug containing those ingredients (drug-level would be ~32,000 duplicated rows). A pair can have several symptoms. `ExampleSentence` is the alert text |
| **Disease / ToAddress** | 73 diseases; 481 drug–disease links | Built from the Kaggle / Hugging Face indication data, with wrong and off-label links removed by hand. The separate IngredientIndication table was dropped |

**Interaction pairs are stored once, with the smaller ID first** (`IngredientID_A < IngredientID_B`). To look up a pair, use `LEAST`/`GREATEST`. The bottom of each setup script has a full example safety-check query (interactions + allergies against active medications) and a side-effect lookup.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Workbench is slow or freezes opening the setup file | Use **File → Run SQL Script** instead of opening it in the editor |
| DBeaver ran only the first statement | Use **Alt+X** (*Execute SQL Script*) |
| PostgreSQL tables went into the wrong database | Connect to `medsafety`, then run the script again |
| `relation "Patient" does not exist` (PostgreSQL) | Remove the double quotes from your query |
| `permission denied for schema public` (PostgreSQL) | Connect as the `postgres` user |
| A check row says **FAIL** | Screenshot the check result and send it to the group chat |

## Notes

- All patients, NRICs, phone numbers, doctors and hospitals are made up.
- Clinical dates are relative to the day you run the script, so "active" medications stay active. **Re-run the setup before a demo** to refresh them.
- `Prescription.ReviewStatus` takes one of three values: `Pending` (waiting for a pharmacist), `Approved` (dispensed) or `Rejected`.
- A medication counts as active when `ReviewStatus = 'Approved'` and today falls between `PrescriptionStart` and `PrescriptionEnd`. A NULL end date means it's ongoing or taken as needed.
- These scripts replace the earlier `medsafety_full_setup.sql`, `clinical_tables.sql` and the CSV-loading scripts.
